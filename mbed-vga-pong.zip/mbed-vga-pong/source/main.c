#include "top_layer/pong.h"

int main(void) {
	initPong();
	startPong();
	return 0;
}
