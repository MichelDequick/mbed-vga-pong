#ifndef VGA_SCREEN_H_
#define VGA_SCREEN_H_

#define SCREEN_HIGHT		60
#define SCREEN_WIDTH		80

extern int screen[SCREEN_HIGHT][SCREEN_WIDTH];

#endif /* VGA_SCREEN_H_ */
