#ifndef MIDDLEWARE_SCREEN_CONTROL_H_
#define MIDDLEWARE_SCREEN_CONTROL_H_

///////////////////// INCLUDES /////////////////////
#include <drivers/VGA/vga_driver.h>

///////////////////// SCREEN /////////////////////
void enableScreen();




#endif /* MIDDLEWARE_SCREEN_CONTROL_H_ */
